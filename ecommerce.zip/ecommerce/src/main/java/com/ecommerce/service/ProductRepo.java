package com.ecommerce.service;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import com.ecommerce.Entites.Product;
@Service
public interface ProductRepo extends CrudRepository<Product, Integer> {

	public List<Product> findAllProductDetails();
	public List<Product> findByType(String p_type);
	public List<Product> findByCategory(String c_type);

	
	
	

}
