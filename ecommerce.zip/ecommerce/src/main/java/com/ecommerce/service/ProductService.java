package com.ecommerce.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.Entites.Product;
@Service
@Transactional
public class ProductService {
	
	@Autowired
	private ProductRepo productRepo;

		public List<Product> getAllProductDetails(){
			return productRepo.findAllProductDetails();
		}
		
		public List<Product> getAllProductByType(String p_type){
			return productRepo.findByType(p_type);
		}
		public List<Product> getAllProductByCategory(String c_type){
			return productRepo.findByCategory(c_type);
		}
}
