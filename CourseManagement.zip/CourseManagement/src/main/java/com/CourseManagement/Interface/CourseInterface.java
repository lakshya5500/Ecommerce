package com.CourseManagement.Interface;

import org.springframework.data.jpa.repository.JpaRepository;

import com.CourseManagement.Entity.Course;

public interface CourseInterface  extends  JpaRepository<Course, Integer>{

}
